let el = document.createElement('div')

document.querySelector('.a').prepend(el)

window.addEventListener('online', (event) => {
    el.textContent = 'Online'
    el.className = 'alert'
    el.classList.add('alert-success')
});

window.addEventListener('offline', (event) => {
    el.textContent = 'offline'
    el.className = 'alert'
    el.classList.add('alert-danger')
});



// -------------------------------
$(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('#main-menu').addClass('scroll');
        } else {
            $('#main-menu').removeClass('scroll');
        }
    })
    $('#main-menu').on('show.bs.collapse', function() {
        $('#main-menu').addClass('scroll')
    })

})