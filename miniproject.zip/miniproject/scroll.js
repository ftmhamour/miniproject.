let sc = document.querySelector('button.scrolls')
window.addEventListener("scroll", e => {

    console.log(window.scrollY)
    if (window.scrollY > 300) {
        sc.classList.add("show")
    } else {

        sc.classList.remove("show")
    }
})

sc.addEventListener("click", e => {
    if (sc.classList.contains('show')) {
        window.scrollTo({ top: 0, behavior: "smooth" })
    }

})